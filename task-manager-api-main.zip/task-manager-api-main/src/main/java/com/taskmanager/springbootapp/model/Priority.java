package com.taskmanager.springbootapp.model;

// Priority.java


public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}

