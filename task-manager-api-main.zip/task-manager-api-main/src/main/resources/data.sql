INSERT INTO Task (title, description, deadline, priority, completed) 
VALUES ('Analysis', 'This is a sample task 1', '2024-05-01', 'HIGH', true);
INSERT INTO Task (title, description, deadline, priority, completed) 
VALUES ('Coding', 'This is a sample task 2', '2024-05-05', 'LOW', false);
INSERT INTO Task (title, description, deadline, priority, completed) 
VALUES ('Unit Testing', 'This is a sample task 3', '2024-06-10', 'HIGH', true);
INSERT INTO Task (title, description, deadline, priority, completed) 
VALUES ('Pushing Code', 'This is a sample task 4', '2024-07-09', 'MEDIUM', false);
INSERT INTO Task (title, description, deadline, priority, completed)
VALUES ('Test on Live', 'This is a sample task 2', '2024-11-20', 'LOW', false);